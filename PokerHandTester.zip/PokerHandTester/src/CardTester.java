import static org.junit.Assert.*;

import org.junit.Test;


public class CardTester {

	@Test
	public void TestComparison() {
		Card h_5 = new Card("Heart", 5);
		Card h_6 = new Card("Heart", 6);
		
		if (h_5.compareCardTo(h_6) >= 0)
			fail("Compare A < B failed.");
		if (h_5.compareCardTo(h_5) != 0)
			fail("Identity Card comparison fail.");
		if (h_6.compareCardTo(h_5) <= 0)
			fail("Compare A > B failed.");
	}
	
	@Test
	public void TestToString() {
		Card h_5 = new Card("Heart", 5);
		if (!h_5.toString().equals("5 of Hearts"))
			fail("Card.toString fails on number card.");
		Card h_j = new Card("Heart", 11);
		if (!h_j.toString().equals("Jack of Hearts"))
			fail("Card.toString fails on Jack card.");
		Card h_q = new Card("Heart", 12);
		if (!h_q.toString().equals("Queen of Hearts"))
			fail("Card.toString fails on Queen card.");
		Card h_k = new Card("Heart", 13);
		if (!h_k.toString().equals("King of Hearts"))
			fail("Card.toString fails on King card.");
		Card h_a = new Card("Heart", 14);
		if (!h_a.toString().equals("Ace of Hearts"))
			fail("Card.toString fails on Ace card.");
	}
	
	@Test
	public void ConstructorTest() {
		Card test;
		try {
			test = new Card("Hearts", 5);
			//If an exception occurs, then it will exit this block in the 
			// previous statement.  Otherwise, it is a failure to detect 
			// the expected exception
			fail("Card accepted bad suit in constructor.");
		} catch (IllegalArgumentException e) { }
		
		try {
			test = new Card("Heart", -1);
			fail("Card accepted bad number in constructor.");
		} catch (IllegalArgumentException e) { } 
		
		try {
			test = new Card("Heart", 16);
			fail("Card accepted bad number in constructor.");
		} catch (IllegalArgumentException e) { }		
	}

}
