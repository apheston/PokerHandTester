
//Basic poker game with four players dealt from a randomly suffled deck
public class Poker {
	public static void main(String[] args) {
		Deck theDeck = new Deck();
		Hand[] hands = new Hand[4];
		for (int i = 0; i < 4; i++) {
			hands[i] = new Hand(theDeck);
			hands[i].printHand();
		}
		
		int currentWinner = 0;
		for (int i = 1; i < 4; i++) {
			if (hands[currentWinner].compareToHand(hands[i]) < 0) {
				currentWinner = i;
			}
		}
		
		int numberOfWinners = 0;
		for (int i = 0; i < 4; i++) {
			if (hands[i].compareToHand(hands[currentWinner]) == 0) {
				System.out.println("Player " + (i+1) + " wins!");
				numberOfWinners++;
			}
		}
		if (numberOfWinners > 1) {
			System.out.println("It is a " + numberOfWinners + "-way tie.");
		}
	}
}
