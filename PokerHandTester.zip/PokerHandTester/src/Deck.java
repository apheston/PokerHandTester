import java.util.Random;

public class Deck {
	// Index of the top card of the deck
	private int cardsDealt;
	private Card[] cards;
	
	public Deck() {
		// Create a standard deck of 52 cards
		createDeck();
		shuffle();
	}
	
	private void createDeck() {
		// Create a standard deck of 52 cards
		cards = new Card[52];
		for (int i = 2; i<=14 ; i++) {
			cards[i-2] = new Card("Diamond", i);
			cards[13 + (i-2)] = new Card("Heart", i);
			cards[26 + (i-2)] = new Card("Club", i);
			cards[39 + (i-2)] = new Card("Spade", i);
		}
		
		this.cardsDealt = 0;	
	}
	
	public Deck(boolean shuffled) {
		createDeck();
		if (shuffled)
			shuffle();
	}
	
	public void shuffle() {
		if (cardsDealt != 0)
			throw new IllegalArgumentException();

		// Shuffle the deck
		Random randSrc = new Random();
		for( int i = 0; i < 52; i++) {
			int randomIndex = randSrc.nextInt(52-i);
			// Swap card i and card randomIndex
			Card temp = cards[i];
			cards[i] = cards[i+randomIndex];
			cards[i+randomIndex] = temp;
		}
	}
	
	public void printTheDeck() {
		for (int i = 0; i < 52; i++) {
			System.out.println(cards[i]);
		}
	}
	
	public Card getTopCard() {
      if (cardsDealt >= 52) {
    	  throw new IllegalArgumentException();
      }
	  Card dealt = cards[cardsDealt];
	  cardsDealt++;
	  return dealt;
	}
	
	public Card[] getCards() {
		return cards;
	}
}
