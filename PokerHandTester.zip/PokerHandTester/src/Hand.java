
public class Hand {
  private Card[] handOfCards;
  // high card: 0
  // pair: 1
  // ...
  private int rank;
  
  public Hand(Deck theDeck) {
	  handOfCards = new Card[5];
	  for (int i=0 ; i < 5; i++) {
		  handOfCards[i] = theDeck.getTopCard();
	  }
	  
	  computeRank();
  }
  
  public Hand(Card c0, Card c1, Card c2, Card c3, Card c4) {
	  handOfCards = new Card[5];
	  handOfCards[0] = c0;
	  handOfCards[1] = c1;
	  handOfCards[2] = c2;
	  handOfCards[3] = c3;
	  handOfCards[4] = c4;
 	  
	  computeRank();
  }
  
  private void computeRank() {
	  //sort the hand
	  for (int i=0; i < 5; i++) {

		  int indexOfHighest = i;
		  //Find highest card from i to the end
		  for (int j=i; j < 5; j++) {
			if (handOfCards[j].compareCardTo(handOfCards[indexOfHighest]) > 0) {
				indexOfHighest = j;
			}
		  }
		  // swap highest card with the card in the front
		  Card swapTemp = handOfCards[i];
		  handOfCards[i] = handOfCards[indexOfHighest];
		  handOfCards[indexOfHighest] = swapTemp;
	  }
	  
	  //Identify the hand rank
	  
	  if (isStraight() && isFlush())
		  rank = 8;
	  else if (isNOfKind(4))
		  rank = 7;
	  else if (isFullHouse())
		  rank = 6;
	  else if (isFlush())
		  rank = 5;
	  else if (isStraight())
		  rank = 4;
	  else if (isNOfKind(3))
		  rank = 3;
	  else if (isTwoPair())
		  rank = 2;
	  else if (isNOfKind(2))
		  rank = 1;
	  else
		  rank = 0;
  }
  
  //Detects a collection of N cards, and 
  // resorts the hand so that a detected collection is moved to the 
  // front of the hand.  Assumes hand has been presorted by card value.
  private boolean isNOfKind(int N) {
	  // N must be between 2 and the size of the hand
	  if (N <= 1 || N > handOfCards.length)
		  throw new IllegalArgumentException();
	  
	  for (int i=0; i <= handOfCards.length - N; i++) {
		  if (handOfCards[i].compareCardTo(handOfCards[i+N-1]) == 0) {
			  //Shift all the cards before the set over.  This loop 
			  // will fill in the cards starting from the rightmost 
			  // card in the set.
			  for (int j=i; j > 0; j--) {
				  Card temp = handOfCards[j+N-1];
				  handOfCards[j+N-1] = handOfCards[j-1];
				  handOfCards[j-1] = temp;
			  }
			  return true;
		  }
	  }
	  return false;
  }
  
  private boolean isTwoPair() {
	  int pairsFound = 0;
	  int kickerIndex = 0;
	  for (int i=0; i < handOfCards.length-1; i++) {
		  if (handOfCards[i].compareCardTo(handOfCards[i+1]) == 0) {
			  pairsFound++;
			  //Skip the whole pair in the loop
			  i++;
		  } else {
			  //Save the index of the unpaired card
			  kickerIndex = i;
		  }
	  }
	  if (pairsFound != 2)
		  return false;
	  //We've found two pairs, now we need to resort, by putting 
	  // the kicker at the end.  Pairs should always be in the 
	  // right order due to the initial sorting.
	  //First, put the kicker at the end
	  Card kicker = handOfCards[kickerIndex];
	  for (int i=kickerIndex; i < handOfCards.length-1; i++) {
		  handOfCards[i] = handOfCards[i+1];
	  }
	  handOfCards[handOfCards.length-1] = kicker;
	  return true;
  }
  
  private boolean isFlush() {
	  //Check if all cards have the same suit
	  for (int i=1; i < handOfCards.length; i++) {
		  if(!handOfCards[0].getSuit().equals(handOfCards[i].getSuit())) {
			  return false;
		  }
	  }
	  //No resorting needed
	  return true;
  }
  
  private boolean isStraight() {
	  //Check that each pair of adjacent cards differs by exactly one in value
	  //Note that we are assuming Aces high, i.e. A, 5, 4, 3, 2 is not a straight
	  //  (official poker rules vary on this, so this is an arbitrary choice)
	  for (int i=0; i < handOfCards.length-1; i++) {
		  if (handOfCards[i].compareCardTo(handOfCards[i+1]) != 1)
			  return false;
	  }
	  //No resorting needed
	  return true;
  }
  	
  //Detects a full house.  In a sorted hand, the first two and last two 
  // cards must be pairs, and the middle card must match one of the pairs.
  private boolean isFullHouse() {
	  if ((handOfCards[0].compareCardTo(handOfCards[1]) == 0) &&
			  	 (handOfCards[3].compareCardTo(handOfCards[4]) == 0)) {
		  if (handOfCards[2].compareCardTo(handOfCards[1]) == 0) {
			  return true; // Three-of-a-kind already at the front
		  }
		  if (handOfCards[2].compareCardTo(handOfCards[3]) == 0) {
			  // Three of a kind at the back, need to be rotated to the front
			  for (int i = 0; i<2; i++) {
				  Card temp = handOfCards[i];
				  handOfCards[i] = handOfCards[4-i];
				  handOfCards[4-i] = temp;
			  }
			  return true;
		  }
	  }
	  return false;
  }
  
  public int getRank() { return rank; }
  
  public void printHand() {
      for(int i = 0; i < handOfCards.length; i++) {
    	  System.out.println(handOfCards[i]);
      }
      System.out.println("Hand is rank: " + rank);
  }
  
  public int compareToHand(Hand other) {
	  if (rank == other.rank) {
		  //At this point, the hands should be sorted by priority, so 
		  // we can compare cards in each location for potential tie-breaks
		  for (int i=0; i < handOfCards.length; i++) {
			  int difference = handOfCards[i].compareCardTo(other.handOfCards[i]);
			  if (difference != 0)
				  return difference;
		  }
		  // No differences found, perfect tie
		  return 0;
	  } else {
		  return rank - other.rank;
	  }
  }
  
}
