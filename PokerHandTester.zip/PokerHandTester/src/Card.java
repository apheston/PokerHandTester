
public class Card {
	//allowed values: "Heart", "Spade", "Diamond", "Club"
	private String suit;
	// values allowed from 2--14
	private int value;
	
	public Card(String suit, int value) {
		if ( (value < 2) || (value > 14) ) {
			throw new IllegalArgumentException();
		}
		if ( !suit.equals("Heart") && !suit.equals("Spade")  && 
				!suit.equals("Diamond") && !suit.equals("Club") ) {
			throw new IllegalArgumentException();
		}
		this.suit = suit;
		this.value = value;
	}
	
	public String toString() {
		switch (value) {
		case 11:
			return "Jack of " + suit + "s";
		case 12:
			return "Queen of " + suit + "s";
		case 13:
			return "King of " + suit + "s";
		case 14:
			return "Ace of " + suit + "s";
		default:		
			return value + " of " + suit + "s";
		}
	}
	
	//color
	
	//return >0 if this.value > other.value
	//return 0 if this.value == other.value
	//return <0 if this.value < other.value
	public int compareCardTo(Card other) {
		return this.value - other.value;
	}
	
	public String getSuit() {
		return suit;
	}
	
}
