import static org.junit.Assert.*;

import org.junit.Test;


public class OfficialHandTestSuite {

	
	//Testing for part 1: ranking hands
	@Test
	public void rankTesting() {
		//Get a sorted deck;
		Deck d = new Deck(false);
		Card[] c = d.getCards();
		
		Hand straightflush = new Hand(c[19], c[23], c[21], c[22], c[20]);
		assertTrue(straightflush.getRank() == 8);
		
		Hand flush = new Hand(c[19], c[23], c[24], c[22], c[20]);
		assertTrue(flush.getRank() == 5);
		
		Hand straight = new Hand(c[19], c[23], c[34], c[22], c[7]);
		assertTrue(straight.getRank() == 4);
		
		Hand fourOfAKind = new Hand(c[4], c[10], c[30], c[17], c[43]);
		assertTrue(fourOfAKind.getRank() == 7);
		
		Hand fullHouse = new Hand(c[4], c[10], c[36], c[17], c[43]);
		assertTrue(fullHouse.getRank() == 6);
		
		Hand threeOfAKind = new Hand(c[4], c[10], c[37], c[17], c[43]);
		assertTrue(threeOfAKind.getRank() == 3);
		
		Hand twoPair = new Hand(c[4], c[10], c[36], c[17], c[46]);
		assertTrue(twoPair.getRank() == 2);
		
		Hand pair = new Hand(c[4], c[10], c[36], c[16], c[46]);
		assertTrue(pair.getRank() == 1);
		
		Hand highCard = new Hand(c[4], c[10], c[39], c[16], c[46]);
		assertTrue(highCard.getRank() == 0);

	}
	
	//Test for part II: hand comparison and tie-breaks
	@Test
	public void compareHandTesting() {
		//Get a sorted deck;
		Deck d = new Deck(false);
		Card[] c = d.getCards();

		Hand straightflush = new Hand(c[19], c[23], c[21], c[22], c[20]);
		Hand flush = new Hand(c[19], c[23], c[24], c[22], c[20]);
		Hand flush2 = new Hand(c[5], c[10], c[11], c[9], c[7]);
		Hand straight = new Hand(c[19], c[23], c[34], c[22], c[7]);
		Hand straight2 = new Hand(c[5], c[9], c[20], c[21], c[6]);
		Hand fourOfAKind = new Hand(c[4], c[10], c[30], c[17], c[43]);
		Hand fourOfAKind2 = new Hand(c[5], c[10], c[31], c[18], c[44]);
		Hand fourOfAKind3 = new Hand(c[5], c[11], c[31], c[18], c[44]);
		Hand fullHouse = new Hand(c[4], c[10], c[36], c[17], c[43]);
		Hand fullHouse2 = new Hand(c[5], c[9], c[35], c[18], c[42]);
		Hand threeOfAKind = new Hand(c[4], c[10], c[37], c[17], c[43]);
		Hand threeOfAKind2 = new Hand(c[4], c[9], c[38], c[17], c[43]);
		Hand twoPair = new Hand(c[4], c[10], c[36], c[17], c[46]);
		Hand pair = new Hand(c[4], c[10], c[36], c[16], c[46]);
		Hand pair2 = new Hand(c[4], c[9], c[35], c[16], c[46]);
		Hand pair3 = new Hand(c[4], c[10], c[36], c[12], c[47]);
		Hand highCard = new Hand(c[3], c[10], c[39], c[16], c[47]);
		Hand highCard2 = new Hand(c[4], c[10], c[39], c[16], c[46]);
		
		//First case - ranks are different
		assertTrue(straightflush.compareToHand(twoPair) > 0);
		assertTrue(pair.compareToHand(twoPair) < 0);
		
		//Second case, ranks equal, no extra sorting needed to break tie
		assertTrue(straight.compareToHand(straight2) > 0); //highest card different
		assertTrue(flush.compareToHand(flush2) > 0); //lowest card different
		assertTrue(highCard.compareToHand(highCard2) > 0); //middle card different
		
		
		//Third case, N of a kinds are broken based on set value first, then 
		// by value of all remaining cards, in order
		assertTrue(fourOfAKind.compareToHand(fourOfAKind2) < 0);
		assertTrue(fourOfAKind2.compareToHand(fourOfAKind3) < 0);
		assertTrue(threeOfAKind.compareToHand(threeOfAKind2) < 0);
		assertTrue(pair.compareToHand(pair2) > 0);
		assertTrue(pair.compareToHand(pair3) < 0);
		assertTrue(highCard.compareToHand(highCard2) > 0);
		
		//Fourth case, full house is compared by the three-of-a-kind first
		assertTrue(fullHouse.compareToHand(fullHouse2) > 0);
		
		//Last case, a "true" tie doesn't break horribly (house rules on 
		// further tie breaks allowed, so we're not checking the value)
		highCard.compareToHand(highCard);
	}

}
