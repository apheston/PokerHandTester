import static org.junit.Assert.*;

import org.junit.Test;


public class DeckTester {

	@Test
	public void testDeck() {
		try {
			Deck d = new Deck(false);
			if (d.getCards().length != 52)
				fail("Deck does not have the proper number of cards.");
			for (int i = 0; i < 13; i++) {
				if (!d.getTopCard().getSuit().equals("Diamond"))
					fail("Deck does not contain 13 Diamonds.");
			}
			for (int i = 0; i < 13; i++) {
				if (!d.getTopCard().getSuit().equals("Heart"))
					fail("Deck does not contain 13 Hearts.");
			}
			for (int i = 0; i < 13; i++) {
				if (!d.getTopCard().getSuit().equals("Club"))
					fail("Deck does not contain 13 Clubs.");
			}
			for (int i = 0; i < 13; i++) {
				if (!d.getTopCard().getSuit().equals("Spade"))
					fail("Deck does not contain 13 Spades.");
			}
		} catch (IllegalArgumentException e) {
			fail("Exception in Deck Testing");
		}
	}

}
